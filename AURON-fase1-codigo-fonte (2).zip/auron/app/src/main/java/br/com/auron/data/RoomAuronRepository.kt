package br.com.auron.data

import android.content.Context
import androidx.room.withTransaction
import br.com.auron.domain.AuronRepository
import br.com.auron.domain.ChatMessage
import br.com.auron.domain.InputLimits
import br.com.auron.domain.Period
import br.com.auron.domain.RoutineItem
import br.com.auron.domain.Task
import java.time.LocalDate
import kotlinx.coroutines.flow.map

class RoomAuronRepository(private val database: AuronDatabase) : AuronRepository {
    constructor(context: Context) : this(AuronDatabase.open(context))

    private val dao = database.dao()

    override val tasks = dao.observeTasks().map { rows -> rows.map { it.toDomain() } }
    override val routineItems = dao.observeRoutineItems().map { rows -> rows.map { it.toDomain() } }
    override val routineCompletions = dao.observeRoutineCompletions().map { rows -> rows.map { it.toDomain() } }
    override val messages = dao.observeMessages().map { rows -> rows.map { it.toDomain() } }

    override suspend fun initialize() = database.withTransaction {
        if (dao.metadata(INITIALIZED_KEY) == null) {
            dao.insertRoutines(initialRoutines())
            dao.saveMetadata(MetadataEntity(INITIALIZED_KEY, "1"))
        }
    }

    override suspend fun saveTask(task: Task) {
        require(task.id.isNotBlank()) { "A tarefa precisa de um identificador." }
        require(task.title.isNotBlank()) { "Informe o título da tarefa." }
        require(task.title.length <= InputLimits.TITLE) { "O título da tarefa é muito longo." }
        require(task.priority in 0..2) { "A prioridade deve estar entre 0 e 2." }
        task.dueDate?.let { LocalDate.parse(it) }
        dao.saveTask(task.toEntity())
    }

    override suspend fun deleteTask(id: String) = dao.deleteTask(id)

    override suspend fun setTaskCompleted(id: String, completed: Boolean, now: Long) = database.withTransaction {
        val task = requireNotNull(dao.task(id)) { "Esta tarefa não existe mais." }
        dao.saveTask(task.copy(completedAt = if (completed) task.completedAt ?: now else null))
    }

    override suspend fun saveRoutine(item: RoutineItem) {
        require(item.id.isNotBlank()) { "A atividade precisa de um identificador." }
        require(item.title.isNotBlank()) { "Informe o título da atividade." }
        require(item.title.length <= InputLimits.TITLE) { "O título da atividade é muito longo." }
        dao.saveRoutine(item.toEntity())
    }

    override suspend fun deleteRoutine(id: String) = dao.deleteRoutine(id)

    override suspend fun setRoutineCompleted(item: RoutineItem, day: String, completed: Boolean, now: Long) {
        LocalDate.parse(day)
        database.withTransaction {
            if (completed) {
                val current = requireNotNull(dao.routine(item.id)) { "Esta atividade não existe mais." }
                dao.insertCompletion(RoutineCompletionEntity(current.id, day, current.title, current.period, now))
            } else {
                dao.deleteCompletion(item.id, day)
            }
        }
    }

    override suspend fun addMessage(message: ChatMessage) {
        require(message.id.isNotBlank() && message.text.isNotBlank()) { "A mensagem não pode ficar vazia." }
        require(message.text.length <= InputLimits.MESSAGE) { "A mensagem é muito longa." }
        dao.addMessage(message.toEntity())
    }

    override suspend fun clearMessages() = dao.clearMessages()

    override suspend fun clearAll() = database.withTransaction {
        dao.clearMessages()
        dao.clearRoutineCompletions()
        dao.clearTasks()
        dao.clearRoutineItems()
        // Also records initialization if deletion was requested before the first seed.
        dao.saveMetadata(MetadataEntity(INITIALIZED_KEY, "1"))
    }

    private fun initialRoutines(): List<RoutineItemEntity> {
        val morning = listOf(
            "Levantar e sair da cama",
            "Escovar os dentes e lavar o rosto",
            "Beber água",
            "Tomar café da manhã",
            "Tomar medicação conforme prescrição cadastrada",
            "Arrumar cama e quarto",
            "Fazer oração matinal",
            "Ler cinco versículos bíblicos",
            "Alongamento ou exercícios",
            "Organizar tarefas da casa",
            "Registrar gastos ou receitas, quando houver",
        )
        val night = listOf(
            "Revisar o dia e as tarefas pendentes",
            "Preparar as prioridades de amanhã",
            "Cuidar da higiene e preparar o descanso",
            "Reservar um momento para reflexão ou oração",
        )
        return morning.mapIndexed { index, title ->
            RoutineItemEntity("initial_morning_$index", title, Period.MORNING.name, index)
        } + night.mapIndexed { index, title ->
            RoutineItemEntity("initial_night_$index", title, Period.NIGHT.name, index)
        }
    }

    private companion object {
        const val INITIALIZED_KEY = "routines_seeded_v1"
    }
}
