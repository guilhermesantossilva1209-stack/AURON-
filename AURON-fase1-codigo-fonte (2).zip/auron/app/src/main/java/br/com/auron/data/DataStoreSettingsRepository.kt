package br.com.auron.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import br.com.auron.domain.AppSettings
import br.com.auron.domain.InputLimits
import br.com.auron.domain.SettingsRepository
import kotlinx.coroutines.flow.map

private val Context.auronSettingsStore by preferencesDataStore(name = "auron_preferences")

class DataStoreSettingsRepository(private val dataStore: DataStore<Preferences>) : SettingsRepository {
    constructor(context: Context) : this(context.applicationContext.auronSettingsStore)

    // IO/corruption errors intentionally propagate so the caller can display a real failure.
    override val settings = dataStore.data.map { preferences ->
        val defaults = AppSettings()
        AppSettings(
            userName = preferences[Keys.userName] ?: defaults.userName,
            speakReplies = preferences[Keys.speakReplies] ?: defaults.speakReplies,
            speechRate = preferences[Keys.speechRate] ?: defaults.speechRate,
            allowOnlineSpeech = preferences[Keys.allowOnlineSpeech] ?: defaults.allowOnlineSpeech,
            humor = preferences[Keys.humor] ?: defaults.humor,
            sarcasm = preferences[Keys.sarcasm] ?: defaults.sarcasm,
            formality = preferences[Keys.formality] ?: defaults.formality,
            proactivity = preferences[Keys.proactivity] ?: defaults.proactivity,
        )
    }

    override suspend fun update(settings: AppSettings) {
        require(settings.userName.isNotBlank()) { "Informe como deseja ser chamado." }
        require(settings.userName.length <= InputLimits.USER_NAME) { "O nome é muito longo." }
        require(settings.speechRate.isFinite() && settings.speechRate in 0.5f..2f) {
            "A velocidade da fala deve estar entre 0,5 e 2." }
        require(listOf(settings.humor, settings.sarcasm, settings.formality, settings.proactivity).all { it in 0..100 }) {
            "Os ajustes de personalidade devem estar entre 0 e 100." }
        dataStore.edit { preferences ->
            preferences[Keys.userName] = settings.userName
            preferences[Keys.speakReplies] = settings.speakReplies
            preferences[Keys.speechRate] = settings.speechRate
            preferences[Keys.allowOnlineSpeech] = settings.allowOnlineSpeech
            preferences[Keys.humor] = settings.humor
            preferences[Keys.sarcasm] = settings.sarcasm
            preferences[Keys.formality] = settings.formality
            preferences[Keys.proactivity] = settings.proactivity
        }
    }

    override suspend fun reset() {
        dataStore.edit { it.clear() }
    }

    private object Keys {
        val userName = stringPreferencesKey("user_name")
        val speakReplies = booleanPreferencesKey("speak_replies")
        val speechRate = floatPreferencesKey("speech_rate")
        val allowOnlineSpeech = booleanPreferencesKey("allow_online_speech")
        val humor = intPreferencesKey("humor")
        val sarcasm = intPreferencesKey("sarcasm")
        val formality = intPreferencesKey("formality")
        val proactivity = intPreferencesKey("proactivity")
    }
}
