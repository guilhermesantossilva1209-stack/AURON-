package br.com.auron.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import br.com.auron.data.DataStoreSettingsRepository
import br.com.auron.data.RoomAuronRepository
import br.com.auron.domain.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.time.LocalDate
import java.util.UUID

data class AuronUiState(
    val ready: Boolean = false,
    val tasks: List<Task> = emptyList(),
    val routineItems: List<RoutineItem> = emptyList(),
    val routineCompletions: List<RoutineCompletion> = emptyList(),
    val messages: List<ChatMessage> = emptyList(),
    val settings: AppSettings = AppSettings(),
    val day: String = LocalDate.now().toString(),
    val error: String? = null,
    val busy: Boolean = false,
    val loadError: String? = null,
)

sealed interface UiEvent {
    data class Navigate(val destination: String) : UiEvent
    data class Speak(val text: String) : UiEvent
}

/** Single owner of user actions. Only explicit user submissions reach CommandParser. */
class AuronViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: AuronRepository = RoomAuronRepository(application)
    private val preferences: SettingsRepository = DataStoreSettingsRepository(application)
    private val provider: AiProvider = DemoAiProvider()
    private val actionMutex = Mutex()
    private val _state = MutableStateFlow(AuronUiState())
    val state: StateFlow<AuronUiState> = _state.asStateFlow()
    private val eventChannel = Channel<UiEvent>(Channel.BUFFERED)
    val events: Flow<UiEvent> = eventChannel.receiveAsFlow()

    private var loadJob: Job? = null

    init { retryLoad() }

    fun retryLoad() {
        loadJob?.cancel()
        _state.update { it.copy(ready = false, loadError = null) }
        loadJob = viewModelScope.launch {
            try {
                repository.initialize()
                combine(repository.tasks, repository.routineItems, repository.routineCompletions,
                    repository.messages, preferences.settings) { tasks, items, completions, messages, settings ->
                    AuronUiState(true, tasks, items, completions, messages, settings)
                }.collect { data ->
                    _state.update { data.copy(error = it.error, busy = it.busy) }
                }
            } catch (error: Exception) {
                if (error is CancellationException) throw error
                _state.update { it.copy(ready = false, loadError = "Não foi possível abrir os dados locais. Verifique o armazenamento e tente novamente. Nenhum dado foi apagado.") }
            }
        }
    }

    private fun action(block: suspend () -> Unit) {
        viewModelScope.launch {
            actionMutex.withLock {
                _state.update { it.copy(busy = true) }
                try {
                    check(_state.value.ready) { "Aguarde a abertura dos dados locais." }
                    block()
                } catch (error: Exception) {
                    if (error is CancellationException) throw error
                    val message = if (error is IllegalArgumentException || error is IllegalStateException)
                        error.message ?: "Revise os campos informados."
                    else "Não foi possível salvar a alteração. Verifique o armazenamento e tente novamente."
                    _state.update { it.copy(error = message) }
                } finally {
                    _state.update { it.copy(busy = false) }
                }
            }
        }
    }

    private fun validatedTitle(value: String): String = value.trim().also {
        require(it.isNotEmpty() && it.length <= 160) { "Use um título de 1 a 160 caracteres." }
    }

    private fun validateTask(task: Task): Task {
        require(task.notes.length <= 4000) { "As observações devem ter até 4.000 caracteres." }
        require(task.priority in 0..2) { "Prioridade inválida." }
        val date = task.dueDate?.trim()?.takeIf { it.isNotEmpty() }
        if (date != null) {
            require(Regex("\\d{4}-\\d{2}-\\d{2}").matches(date) && runCatching { LocalDate.parse(date) }.isSuccess) {
                "Informe uma data válida no formato AAAA-MM-DD."
            }
        }
        return task.copy(title = validatedTitle(task.title), notes = task.notes.trim(), dueDate = date)
    }

    fun addTask(title: String, notes: String, priority: Int, dueDate: String?) = action {
        repository.saveTask(validateTask(Task(UUID.randomUUID().toString(), title, notes, priority, dueDate, System.currentTimeMillis())))
    }

    fun updateTask(task: Task) = action {
        val current = requireNotNull(repository.tasks.first().find { it.id == task.id }) { "Esta tarefa não existe mais." }
        repository.saveTask(validateTask(current.copy(title = task.title, notes = task.notes, priority = task.priority, dueDate = task.dueDate)))
    }
    fun deleteTask(id: String) = action { repository.deleteTask(id) }
    fun toggleTask(task: Task) = action {
        val current = requireNotNull(repository.tasks.first().find { it.id == task.id }) { "Esta tarefa não existe mais." }
        repository.setTaskCompleted(task.id, current.completedAt == null, System.currentTimeMillis())
    }
    fun addRoutine(title: String, period: Period) = action {
        val order = (repository.routineItems.first().filter { it.period == period }.maxOfOrNull { it.orderIndex } ?: -1) + 1
        repository.saveRoutine(RoutineItem(UUID.randomUUID().toString(), validatedTitle(title), period, order))
    }
    fun saveRoutine(item: RoutineItem) = action {
        val current = requireNotNull(repository.routineItems.first().find { it.id == item.id }) { "Esta atividade não existe mais." }
        repository.saveRoutine(current.copy(title = validatedTitle(item.title)))
    }
    fun deleteRoutine(id: String) = action { repository.deleteRoutine(id) }
    fun toggleRoutine(item: RoutineItem) = action {
        val today = LocalDate.now().toString()
        val done = repository.routineCompletions.first().any { it.itemId == item.id && it.day == today }
        repository.setRoutineCompleted(item, today, !done, System.currentTimeMillis())
        refreshDay()
    }
    fun saveSettings(settings: AppSettings) = action {
        require(settings.userName.trim().length in 1..60) { "Use um nome de 1 a 60 caracteres." }
        require(settings.speechRate.isFinite()) { "Velocidade inválida." }
        preferences.update(settings.copy(userName = settings.userName.trim(), speechRate = settings.speechRate.coerceIn(0.5f, 2f),
            humor = settings.humor.coerceIn(0, 100), sarcasm = settings.sarcasm.coerceIn(0, 100),
            formality = settings.formality.coerceIn(0, 100), proactivity = settings.proactivity.coerceIn(0, 100)))
    }
    fun dismissError() { _state.update { it.copy(error = null) } }
    fun refreshDay() { _state.update { it.copy(day = LocalDate.now().toString()) } }
    fun clearChat() = action { repository.clearMessages() }
    fun clearAll() = action {
        repository.clearAll()
        preferences.reset()
    }

    fun send(text: String, source: String = "text") = action {
        val input = text.trim()
        require(input.length in 1..4000) { "Envie uma mensagem de 1 a 4.000 caracteres." }
        require(source == "text" || source == "voice") { "Origem de comando não autorizada." }
        val now = System.currentTimeMillis()
        repository.addMessage(ChatMessage(UUID.randomUUID().toString(), "user", input, now, source))
        val reply = handle(CommandParser.parse(input), input)
        repository.addMessage(ChatMessage(UUID.randomUUID().toString(), "assistant", reply, System.currentTimeMillis(), "demo"))
        if (preferences.settings.first().speakReplies) eventChannel.send(UiEvent.Speak(reply))
    }

    private suspend fun handle(command: LocalCommand, input: String): String {
        val snapshot = _state.value.copy(tasks = repository.tasks.first(), routineItems = repository.routineItems.first(), settings = preferences.settings.first())
        return when (command) {
            LocalCommand.Morning -> {
                eventChannel.send(UiEvent.Navigate("routine/morning"))
                "Bom dia, ${snapshot.settings.userName}. Rotina matinal aberta. ${pending(Period.MORNING)}"
            }
            LocalCommand.Night -> {
                eventChannel.send(UiEvent.Navigate("routine/night"))
                "Checklist noturno aberto. ${pending(Period.NIGHT)}"
            }
            LocalCommand.ShowRoutine -> {
                eventChannel.send(UiEvent.Navigate("routine"))
                "Sua rotina está aberta. Você pode editar cada atividade."
            }
            LocalCommand.Pending -> {
                val tasks = snapshot.tasks.filter { it.completedAt == null }
                "Há ${tasks.size} tarefa(s) pendente(s). ${pending(Period.MORNING)}" +
                    tasks.take(5).joinToString("", prefix = if (tasks.isEmpty()) "" else " Prioridades:") { "\n• ${it.title}" }
            }
            is LocalCommand.CreateTask -> {
                repository.saveTask(validateTask(Task(UUID.randomUUID().toString(), command.title, createdAt = System.currentTimeMillis())))
                "Tarefa criada no dispositivo: ${command.title}."
            }
            is LocalCommand.CompleteTask -> {
                val matches = snapshot.tasks.filter { it.completedAt == null && normalized(it.title) == normalized(command.title) }
                if (matches.size == 1) {
                    repository.setTaskCompleted(matches.single().id, true, System.currentTimeMillis())
                    "Tarefa concluída: ${matches.single().title}. Ela está no histórico."
                } else if (matches.isEmpty()) "Não encontrei uma tarefa pendente com esse título exato. Abra Tarefas para conferir."
                else "Há mais de uma tarefa com esse título. Selecione a desejada na tela Tarefas."
            }
            is LocalCommand.CompleteRoutine -> {
                val matches = snapshot.routineItems.filter { normalized(it.title) == normalized(command.title) }
                if (matches.size == 1) {
                    repository.setRoutineCompleted(matches.single(), LocalDate.now().toString(), true, System.currentTimeMillis())
                    "Atividade concluída hoje: ${matches.single().title}."
                } else "Preciso de um título único e completo. Selecione a atividade na tela Rotina."
            }
            is LocalCommand.Navigate -> {
                eventChannel.send(UiEvent.Navigate(command.destination))
                "Tela solicitada aberta."
            }
            LocalCommand.Help, LocalCommand.Unknown -> when (val response = provider.reply(input, snapshot.settings)) {
                is ProviderResult.Success -> response.text
                is ProviderResult.Unavailable -> "Provedor indisponível: ${response.reason}. As tarefas e rotinas locais continuam disponíveis."
            }
        }
    }

    private suspend fun pending(period: Period): String {
        val items = repository.routineItems.first()
        val today = LocalDate.now().toString()
        val done = repository.routineCompletions.first().filter { it.day == today }.map { it.itemId }.toSet()
        val pending = items.count { it.period == period && it.id !in done }
        return "${pending} atividade(s) restante(s) na rotina ${if (period == Period.MORNING) "matinal" else "noturna"}."
    }

    private fun normalized(value: String) = Normalizer.normalize(value.trim().lowercase(java.util.Locale.ROOT), Normalizer.Form.NFD)
        .replace(Regex("\\p{M}+"), "").replace(Regex("\\s+"), " ")

    /** Explicit user export only. Never invoked by a provider or a parsed command. */
    suspend fun exportJson(): String = actionMutex.withLock {
        check(state.value.ready) { "Aguarde o carregamento dos dados." }
        val tasks = repository.tasks.first()
        val routines = repository.routineItems.first()
        val completions = repository.routineCompletions.first()
        val messages = repository.messages.first()
        val settings = preferences.settings.first()
        JSONObject().apply {
            put("format", "auron-export")
            put("version", 1)
            put("exportedAt", java.time.Instant.now().toString())
            put("tasks", JSONArray().apply { tasks.forEach { task -> put(JSONObject().apply {
                put("id", task.id); put("title", task.title); put("notes", task.notes); put("priority", task.priority)
                put("dueDate", task.dueDate ?: JSONObject.NULL); put("createdAt", task.createdAt)
                put("completedAt", task.completedAt ?: JSONObject.NULL)
            }) } })
            put("routineItems", JSONArray().apply { routines.forEach { item -> put(JSONObject().apply {
                put("id", item.id); put("title", item.title); put("period", item.period.name); put("orderIndex", item.orderIndex)
            }) } })
            put("routineCompletions", JSONArray().apply { completions.forEach { completion -> put(JSONObject().apply {
                put("itemId", completion.itemId); put("day", completion.day); put("title", completion.title)
                put("period", completion.period.name); put("completedAt", completion.completedAt)
            }) } })
            put("messages", JSONArray().apply { messages.forEach { message -> put(JSONObject().apply {
                put("id", message.id); put("role", message.role); put("text", message.text)
                put("createdAt", message.createdAt); put("source", message.source)
            }) } })
            put("settings", JSONObject().apply {
                put("userName", settings.userName); put("speakReplies", settings.speakReplies); put("speechRate", settings.speechRate)
                put("allowOnlineSpeech", settings.allowOnlineSpeech); put("humor", settings.humor); put("sarcasm", settings.sarcasm)
                put("formality", settings.formality); put("proactivity", settings.proactivity)
            })
        }.toString(2)
    }
}
