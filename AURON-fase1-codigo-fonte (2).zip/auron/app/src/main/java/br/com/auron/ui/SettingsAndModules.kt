package br.com.auron.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import br.com.auron.domain.AppSettings
import br.com.auron.ui.theme.AuronColors
import kotlin.math.roundToInt

@Composable
internal fun SettingsScreen(
    settings: AppSettings,
    save: (AppSettings) -> Unit,
    clearChat: () -> Unit,
    clearAll: () -> Unit,
    export: () -> Unit,
) {
    var draft by remember(settings) { mutableStateOf(settings) }
    var confirming by remember { mutableStateOf<String?>(null) }
    val dirty = draft != settings
    LazyColumn(Modifier.fillMaxSize().testTag("screen_settings"), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item { ScreenHeading("Do seu jeito", "Preferências, voz e controle dos seus registros.") }
        item {
            SettingsPanel("Identidade") {
                OutlinedTextField(value = draft.userName, onValueChange = { if (it.length <= 60) draft = draft.copy(userName = it) }, label = { Text("Como devo chamar você?") }, singleLine = true, modifier = Modifier.fillMaxWidth().testTag("settings_name"), supportingText = { Text("Seu nome ou um tratamento, como comandante.") })
            }
        }
        item {
            SettingsPanel("Voz") {
                SettingToggle("Falar respostas", "Usa uma voz pt-BR instalada no dispositivo. A disponibilidade depende do Android.", draft.speakReplies) { draft = draft.copy(speakReplies = it) }
                Spacer(Modifier.height(16.dp))
                Text("Velocidade de fala · ${String.format(java.util.Locale.forLanguageTag("pt-BR"), "%.1f", draft.speechRate)}×", style = MaterialTheme.typography.labelLarge)
                Slider(value = draft.speechRate, onValueChange = { draft = draft.copy(speechRate = it) }, valueRange = 0.5f..2f, steps = 14, modifier = Modifier.semantics { contentDescription = "Velocidade de fala" })
                HorizontalDivider(color = AuronColors.Elevated, modifier = Modifier.padding(vertical = 12.dp))
                SettingToggle("Permitir reconhecimento online", "Consentimento opcional: quando o reconhecimento local não estiver disponível, o serviço de voz do Android poderá enviar seu áudio ao provedor configurado no aparelho. Desativado por padrão.", draft.allowOnlineSpeech) { draft = draft.copy(allowOnlineSpeech = it) }
                Spacer(Modifier.height(12.dp))
                Text("AURON só escuta após seu toque, com o aplicativo aberto. A permissão de microfone é solicitada nesse momento.", style = MaterialTheme.typography.bodySmall, color = AuronColors.Muted)
            }
        }
        item {
            SettingsPanel("Personalidade") {
                Text("Preferências armazenadas para a evolução do assistente. O modo atual responde com comandos e textos programados; estes controles não representam um modelo de IA conectado.", style = MaterialTheme.typography.bodySmall, color = AuronColors.Muted)
                Spacer(Modifier.height(16.dp))
                PercentageSlider("Humor", draft.humor) { draft = draft.copy(humor = it) }
                PercentageSlider("Sarcasmo leve", draft.sarcasm) { draft = draft.copy(sarcasm = it) }
                PercentageSlider("Formalidade", draft.formality) { draft = draft.copy(formality = it) }
                PercentageSlider("Proatividade", draft.proactivity) { draft = draft.copy(proactivity = it) }
                Text("Lembretes e notificações proativas ainda estão planejados.", style = MaterialTheme.typography.bodySmall, color = AuronColors.Muted)
            }
        }
        item {
            Button(onClick = { save(draft.copy(userName = draft.userName.trim())) }, enabled = dirty && draft.userName.isNotBlank(), modifier = Modifier.fillMaxWidth().testTag("settings_save")) { Icon(Icons.Outlined.Save, null); Spacer(Modifier.width(8.dp)); Text("Salvar preferências") }
            Text(if (dirty) "Há alterações ainda não salvas." else "Preferências sincronizadas com o armazenamento local.", color = AuronColors.Muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
        }
        item {
            SettingsPanel("Privacidade & dados") {
                Text("Tarefas, rotinas, conversas e preferências ficam no armazenamento privado do aplicativo. O backup automático está desativado. Nesta versão, os registros não possuem criptografia adicional nem bloqueio por senha próprio.", style = MaterialTheme.typography.bodyMedium, color = AuronColors.Muted)
                Spacer(Modifier.height(14.dp))
                OutlinedButton(onClick = export, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Outlined.FileDownload, null); Spacer(Modifier.width(8.dp)); Text("Exportar meus dados") }
                Text("Arquivo JSON legível contendo também o histórico de conversas. Você escolhe onde salvar. Importação ainda não disponível.", style = MaterialTheme.typography.bodySmall, color = AuronColors.Muted)
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = { confirming = "chat" }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Outlined.DeleteSweep, null); Spacer(Modifier.width(8.dp)); Text("Limpar conversas") }
                TextButton(onClick = { confirming = "all" }, modifier = Modifier.fillMaxWidth()) { Text("Apagar todos os dados locais", color = AuronColors.Danger) }
            }
        }
        item {
            Text("AURON · v0.1 · Fundação funcional", style = MaterialTheme.typography.labelLarge, color = AuronColors.Gold)
            Spacer(Modifier.height(6.dp))
            Text("Sem provedor externo de IA, publicação social ou execução de operações financeiras. As integrações futuras exigirão configuração e permissões próprias.", style = MaterialTheme.typography.bodySmall, color = AuronColors.Muted)
        }
    }
    when (confirming) {
        "chat" -> ConfirmDialog("Limpar conversas?", "Todo o histórico de mensagens e transcrições será apagado deste dispositivo. Esta ação não pode ser desfeita.", "Limpar", { confirming = null }) { clearChat(); confirming = null }
        "all" -> ConfirmDialog("Apagar todos os dados?", "Tarefas, atividades da rotina, conclusões, conversas e preferências serão apagados. A rotina inicial não será recriada automaticamente. Exporte seus registros antes, se quiser mantê-los. Esta ação não pode ser desfeita.", "Apagar tudo", { confirming = null }) { clearAll(); confirming = null }
    }
}

@Composable
private fun SettingsPanel(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(color = AuronColors.Surface, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(18.dp))
            content()
        }
    }
}

@Composable
private fun SettingToggle(title: String, detail: String, checked: Boolean, change: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(6.dp))
            Text(detail, style = MaterialTheme.typography.bodySmall, color = AuronColors.Muted)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = change, modifier = Modifier.semantics { contentDescription = title })
    }
}

@Composable
private fun PercentageSlider(title: String, value: Int, change: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth()) {
        Text(title, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelLarge)
        Text("$value%", color = AuronColors.Gold, style = MaterialTheme.typography.labelLarge)
    }
    Slider(value = value.toFloat(), onValueChange = { change(it.roundToInt()) }, valueRange = 0f..100f, steps = 19, modifier = Modifier.semantics { contentDescription = title })
}

private data class PlannedModule(val name: String, val tag: String, val icon: ImageVector, val detail: String)
private val plannedModules = listOf(
    PlannedModule("Inteligência & memória", "FASE 2", Icons.Outlined.Psychology, "Provedor de IA substituível, contexto e memória controlada. A interface de provedores já existe; nenhum serviço externo está conectado."),
    PlannedModule("Automações Android", "FASE 3", Icons.Outlined.Bolt, "Intents, lembretes e notificações autorizadas. Sem ações ocultas ou controle de outros aplicativos nesta versão."),
    PlannedModule("Estudos", "FASE 4", Icons.Outlined.School, "Ciclos prolongados de aprendizagem, foco e revisões. Prioridade inicial: social media e edição audiovisual."),
    PlannedModule("Clau Estética", "FASE 4", Icons.Outlined.AutoAwesome, "Calendário editorial, campanhas, roteiros e métricas. APIs oficiais de redes sociais poderão ser integradas futuramente."),
    PlannedModule("Editor audiovisual premium", "FASE 4", Icons.Outlined.Movie, "Briefing, storyboard e etapas de edição. Preparação para ferramentas como Remotion; sem análise ou renderização de vídeos nesta versão."),
    PlannedModule("Finanças pessoais", "FASE 4", Icons.Outlined.AccountBalanceWallet, "Receitas, despesas, orçamento e cálculos verificáveis. Os registros financeiros ainda não estão disponíveis."),
    PlannedModule("Registro de operações", "FASE 4", Icons.Outlined.QueryStats, "Diário de sessões, WIN/LOSS e análise de risco. Somente registro e cálculo; nenhuma execução automática de operações."),
    PlannedModule("Espaço pessoal", "FASE 4", Icons.Outlined.SelfImprovement, "Diário, emoções e exercícios de respiração. Recursos de apoio que não substituem acompanhamento profissional."),
    PlannedModule("Espiritualidade", "FASE 4 · OPCIONAL", Icons.Outlined.MenuBook, "Leituras, reflexões e orações pessoais. Ativação e conteúdo sob seu controle."),
)

@Composable
internal fun ModulesScreen(navigate: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().testTag("screen_modules"), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            ScreenHeading("Um sistema. Novas possibilidades.", "A fundação está em construção contínua. Veja o que já funciona e o que vem depois.")
            Spacer(Modifier.height(20.dp))
            Text("DISPONÍVEL NESTA VERSÃO", style = MaterialTheme.typography.labelMedium, color = AuronColors.Gold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { navigate("chat") }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 12.dp)) { Text("Conversa") }
                OutlinedButton(onClick = { navigate("routine") }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 12.dp)) { Text("Rotina") }
                OutlinedButton(onClick = { navigate("tasks") }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 12.dp)) { Text("Tarefas") }
            }
            Spacer(Modifier.height(22.dp))
            Text("MAPA DE EVOLUÇÃO · AINDA NÃO IMPLEMENTADO", style = MaterialTheme.typography.labelMedium, color = AuronColors.Muted)
        }
        items(plannedModules, key = { it.name }) { module ->
            Surface(color = AuronColors.Surface, shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.Top) {
                    Icon(module.icon, null, tint = AuronColors.Gold, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(18.dp))
                    Column(Modifier.weight(1f)) {
                        Text(module.tag + " · PLANEJADO", style = MaterialTheme.typography.labelSmall, color = AuronColors.Muted)
                        Spacer(Modifier.height(5.dp))
                        Text(module.name, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        Text(module.detail, color = AuronColors.Muted, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
    }
}
