package br.com.auron.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        TaskEntity::class,
        RoutineItemEntity::class,
        RoutineCompletionEntity::class,
        ChatMessageEntity::class,
        MetadataEntity::class,
    ],
    version = 1,
    exportSchema = true,
)
abstract class AuronDatabase : RoomDatabase() {
    abstract fun dao(): AuronDao

    companion object {
        @Volatile private var instance: AuronDatabase? = null

        fun open(context: Context): AuronDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                AuronDatabase::class.java,
                "auron.db",
            ).build().also { instance = it }
        }
    }
}
