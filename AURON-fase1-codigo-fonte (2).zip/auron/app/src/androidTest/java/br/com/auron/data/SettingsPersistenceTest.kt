package br.com.auron.data

import android.content.Context
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import br.com.auron.domain.AppSettings
import java.io.File
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.fail
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class SettingsPersistenceTest {
    @Test
    fun preferencesAndExplicitSpeechConsentSurviveStoreReopen() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val file = File(context.cacheDir, "settings-${UUID.randomUUID()}.preferences_pb")
        var scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        try {
            var repository = DataStoreSettingsRepository(
                PreferenceDataStoreFactory.create(scope = scope, produceFile = { file }),
            )
            val defaults = repository.settings.first()
            assertEquals(AppSettings(), defaults)
            assertFalse(defaults.allowOnlineSpeech)
            assertFalse(defaults.speakReplies)
            val selected = AppSettings(
                userName = "Ana",
                speakReplies = true,
                speechRate = 1.25f,
                allowOnlineSpeech = true,
                humor = 70,
                sarcasm = 25,
                formality = 80,
                proactivity = 40,
            )
            repository.update(selected)
            scope.coroutineContext[Job]!!.cancelAndJoin()
            scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
            repository = DataStoreSettingsRepository(
                PreferenceDataStoreFactory.create(scope = scope, produceFile = { file }),
            )

            assertEquals(selected, repository.settings.first())
            repository.reset()
            assertEquals(AppSettings(), repository.settings.first())
        } finally {
            scope.coroutineContext[Job]!!.cancelAndJoin()
            file.delete()
        }
    }

    @Test
    fun invalidSettingsLeaveTheLastSavedPreferencesUntouched() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val file = File(context.cacheDir, "settings-${UUID.randomUUID()}.preferences_pb")
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        try {
            val repository = DataStoreSettingsRepository(
                PreferenceDataStoreFactory.create(scope = scope, produceFile = { file }),
            )
            val valid = AppSettings(userName = "Comandante")
            repository.update(valid)
            try {
                repository.update(valid.copy(speechRate = Float.NaN))
                fail("A velocidade inválida deveria ser rejeitada.")
            } catch (_: IllegalArgumentException) {
                // Expected validation failure, before changing the preferences file.
            }
            assertEquals(valid, repository.settings.first())
        } finally {
            scope.coroutineContext[Job]!!.cancelAndJoin()
            file.delete()
        }
    }
}
