# AURON — Sistema de Inteligência Pessoal

Fundação Android nativa em português brasileiro. **Versão 0.1: comandos locais e
chat demonstrativo; nenhum modelo de IA ou serviço pago conectado.** Código
implementado, mas ainda não compilado nem validado em Android neste ambiente.

## O que esta versão contém

- Centro de comando preto e dourado, núcleo robótico vetorial, relógio, pendências
  reais e progresso da rotina. Layout com menu lateral em telas a partir de 840 dp.
- Tarefas com título, observações, prioridade, prazo, edição, conclusão, reabertura
  e exclusão. Histórico de tarefas concluídas.
- Rotinas matinal e noturna editáveis, com conclusão por data e histórico.
- Conversa demonstrativa persistida e comandos explícitos de texto/voz.
- Configurações persistidas de nome, personalidade, voz e consentimento.
- Adaptadores de reconhecimento de fala e síntese em pt-BR; dependem dos serviços
  instalados no Android. Consulte [voz e teste no dispositivo](docs/VOICE.md).
- Exportação JSON pelo seletor do Android e exclusão de dados com confirmação.
- Catálogo dos próximos módulos, identificado como planejamento.

O estado real de compilação e testes está em [VALIDATION.md](docs/VALIDATION.md).
Código escrito ou compilado não equivale a validação em um tablet físico.

## Arquitetura

Kotlin, Jetpack Compose e Material 3, com fluxo unidirecional de estado e ViewModel.
Room guarda dados estruturados; DataStore guarda preferências. Coroutines e Flow
atualizam a interface sem acesso ao banco na thread principal. A injeção manual
mantém esta primeira versão pequena, sem framework de DI.

```text
app/src/main/java/br/com/auron/
  MainActivity.kt        ciclo de vida, exportação pelo SAF
  domain/               modelos, repositórios, comandos e interface AiProvider
  data/                 Room, DAOs, entidades, DataStore
  ui/                   ViewModel, telas Compose e tema
  voice/                SpeechRecognizer e TextToSpeech
app/src/test/           testes JVM dos comandos e do provedor demonstrativo
app/src/androidTest/    testes Android de persistência e interface
app/schemas/            destino do esquema Room gerado na primeira compilação
docs/                  arquitetura, privacidade, validação e evolução
.github/workflows/      compilação automatizada, sem publicação
```

Veja [decisões técnicas](docs/ARCHITECTURE.md) e [privacidade](docs/PRIVACY.md).

## Comandos disponíveis

```text
Bom dia, AURON.
Mostre minha rotina.
O que falta fazer?
Criar tarefa: Revisar roteiro da Clau
Concluir tarefa: Revisar roteiro da Clau
Concluir atividade: Beber água
Boa noite, AURON.
Abrir configurações
Ajuda
```

Conclusão por comando exige um título exato e único. Um comando ambíguo não escolhe
uma atividade arbitrariamente. Respostas do provedor nunca são executadas como
comandos. O histórico informa quando a entrada veio de voz.

## Compilar

Requisitos: JDK 17, **Gradle 8.10.2 instalado**, Android SDK com plataforma 35 e
Build Tools 35.0.0, acesso à internet na primeira compilação. Android mínimo:
**8.0 / API 26**. Não são necessárias chaves de API.

Esta entrega não contém `gradlew`, `gradlew.bat` nem `gradle-wrapper.jar`: o acesso
à rede necessário para obtê-los foi bloqueado. Os arquivos de configuração Gradle
existem e podem ser utilizados pelo Gradle instalado. Não há APK nesta entrega.

1. Abra esta pasta no Android Studio com suporte a AGP 8.7.3 ou use o terminal.
2. Defina `ANDROID_HOME` para o SDK, ou crie `local.properties` com
   `sdk.dir=/caminho/do/android-sdk`. Não publique esse arquivo.
3. Execute:

```bash
gradle --no-daemon testDebugUnitTest lintDebug assembleDebug assembleDebugAndroidTest
```

No Windows use o comando `gradle` da instalação 8.10.2. O APK do app ficará em
`app/build/outputs/apk/debug/app-debug.apk`. Relatórios ficam em
`app/build/reports/`. Para testes Android, conecte um dispositivo com depuração USB
ou inicie um emulador e execute:

```bash
gradle --no-daemon connectedDebugAndroidTest
```

## Compilar usando somente o tablet

Para gerar o wrapper oficial depois de instalar Gradle 8.10.2, use
`sh scripts/create-wrapper.sh` em Linux/macOS. O gerador usa um projeto temporário
isolado e modo offline; não instala ferramentas. Depois disso é possível substituir
`gradle` por `./gradlew`. Consulte [scripts](scripts/README.md).

O Gradle Android oficial utiliza ferramentas nativas de computador: Termux sozinho
não é uma rota oficialmente suportada por este projeto. Use o navegador do tablet
para abrir um ambiente Linux de desenvolvimento na nuvem ou um repositório GitHub
seu com estes arquivos. O workflow incluído pode ser executado manualmente em
**Actions → Android — compilar e verificar → Run workflow** e disponibiliza o
artefato `AURON-APK-e-relatorios` quando a compilação tem sucesso. Marque a opção
`instrumentation` para também executar os testes Android em tablet emulado.
O workflow instala Gradle 8.10.2 diretamente e não depende do wrapper ausente.
Baixe o ZIP do artefato e extraia o APK no tablet. A disponibilidade e gratuidade
do executor dependem da conta e dos limites do serviço; este projeto não contrata
serviços nem cria repositórios externos automaticamente.

O workflow foi preparado, mas não executado nesta entrega; erros encontrados na
primeira compilação precisam ser corrigidos antes de considerar a Fase 1 validada.

## Instalar no tablet

1. Gere o APK seguindo a seção anterior e confira que o tablet usa Android 8 ou superior.
2. Transfira ou baixe o APK de depuração e abra-o pelo gerenciador de arquivos.
3. Se o Android solicitar, autorize temporariamente a instalação por esse
   gerenciador/navegador. Depois da instalação, desative essa autorização.
4. Abra **AURON**. O microfone só é solicitado ao tocar no botão de voz.
5. Crie uma tarefa, conclua-a e verifique o histórico. Feche o app e abra novamente
   para validar a persistência no seu aparelho.

Com computador e ADB: `adb install -r app/build/outputs/apk/debug/app-debug.apk`.

O APK de depuração é para desenvolvimento, não para distribuição em loja. Antes de
usar dados importantes, defina uma chave de assinatura estável para as versões
futuras: APKs assinados com chaves diferentes não atualizam a mesma instalação.
Desinstalar apaga dados locais. A exportação desta versão é para consulta/backup;
**importação e restauração ainda não estão implementadas**.

## Limites e próxima etapa

Não há IA generativa, pesquisa na web, notificações, lembretes agendados, escuta
contínua, palavra de ativação, execução externa ou edição/renderização de vídeo.
Finanças, estudos, Clau Estética, diário, espiritualidade e editor audiovisual
constam no [plano de evolução](docs/ROADMAP.md).

Preferências de sarcasmo, formalidade e proatividade ficam guardadas para a fase
de IA; não representam um modelo de personalidade ativo. Humor altera apenas uma
saudação fixa do demonstrador. O app não analisa emoções, saúde ou investimentos.

Os dados ficam no armazenamento privado do app, sem criptografia adicional do
banco ou bloqueio biométrico nesta versão. Evite armazenar segredos até essa camada
ser implementada. Backup automático está desativado; uma exportação JSON contém
texto legível e deve ser guardada em local de sua escolha e confiança.
