# Retomar o desenvolvimento sem reiniciar

Estado salvo em 18/10/2026. A implementação está na pasta `app`; não gerar outro
projeto por cima dela. Leia README, VALIDATION e ACCEPTANCE antes de continuar.

## Primeiro passo útil

Usar executor com Gradle 8.10.2 e SDK Android instalados, ou executar o workflow
incluído em repositório controlado pelo usuário. Evitar repetir downloads neste
executor enquanto a conexão ao proxy estiver indisponível. Nenhuma conta externa
foi criada e nenhum workflow remoto foi executado.

## Comandos de validação, quando houver ferramentas

```bash
gradle --no-daemon testDebugUnitTest lintDebug assembleDebug assembleDebugAndroidTest
gradle --no-daemon connectedDebugAndroidTest
```

Corrigir falhas reais de compilação/teste que aparecerem, preservar dados e criar
migrações explícitas quando alterar entidades. Os testes escritos ainda não rodaram.
Capturar a interface em emulador tablet e verificar teclado, fonte ampliada e voz
em dispositivo com mecanismos pt-BR. Não usar previews como evidência de execução.

## O que já foi corrigido

- Alternância de conclusão consulta o banco dentro do mutex, sem usar snapshot antigo.
- Edição preserva o estado de conclusão atual da tarefa.
- Falha de carga interrompe interação e oferece nova tentativa.
- UI limita títulos a 160 caracteres e aceita velocidade de voz até 2×.
- Síntese não inicia após saída do app; permissão e preferências são respeitadas.
- O painel tem entrada real de texto e o comando noturno abre a rotina correta.
- CI usa Gradle instalado e não tenta chamar wrapper ausente.

## Artefatos e verificação local

`docs/static-checks.json`: 9 verificações estáticas aprovadas. Para repetir:
`python3 scripts/check-source.py`. Não confundir com 20 testes JVM e 11 testes
instrumentados, que continuam pendentes. O arquivo `SOURCE-SHA256.txt` na raiz
da entrega lista hashes dos arquivos empacotados, exceto ele próprio.
