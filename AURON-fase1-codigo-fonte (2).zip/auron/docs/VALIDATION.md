# Estado real da entrega — 18/10/2026

**Código da fundação implementado; Fase 1 ainda não validada em Android.** Não foi
gerado APK. Não há resultado de compilação, Android Lint, JUnit ou testes de
dispositivo. Nenhum cenário bloqueado é tratado como aprovado.

## Trabalho preservado e concluído

A retomada encontrou fontes Kotlin, recursos XML, configurações Gradle, workflow,
testes e documentação salvos em `/workspace/auron`. Foi criado um snapshot anterior
à revisão final em `/workspace/auron-preservado-antes-da-revisao.zip`. O projeto
não foi reiniciado e nenhum módulo implementado foi substituído por um protótipo.

Implementados no código:

- Sete destinos de navegação, painel responsivo, núcleo Canvas preto/dourado,
  prioridades reais e entrada de comando no painel.
- Tarefas editáveis com conclusão/histórico, rotinas manhã/noite por data e
  persistência Room; configurações DataStore; exportação JSON por SAF.
- Parser local conservador, provedor demonstrativo explícito e conversa persistida.
- Voz pt-BR, consentimento para reconhecimento externo, TTS offline, interrupção
  e liberação no ciclo de vida, condicionados aos serviços disponíveis no Android.
- Correções de estado obsoleto em alternância de conclusão e edição de tarefa,
  alinhamento de limites de título/velocidade e recuperação de erro de carregamento.
- CI com Gradle 8.10.2 instalado diretamente, sem depender de wrapper ausente.

## Verificações executáveis sem rede

`python3 scripts/check-source.py` verifica XML, recursos referenciados, Activity,
componentes de código, permissões, exclusões de backup e links da documentação.
Resultado executado: **9 de 9 verificações estáticas aprovadas**, em
[static-checks.json](static-checks.json). Isso **não valida
sintaxe Kotlin, APIs Compose, geração Room ou comportamento Android**.

`sh -n scripts/create-wrapper.sh` passou na verificação de sintaxe shell. A execução
sem Gradle falhou imediatamente com código 1 e mensagem explicativa, como esperado;
não foi gerado wrapper. O YAML do workflow foi analisado localmente e suas
versões/comandos conferidos: ambos os jobs usam Gradle 8.10.2 sem `./gradlew`.

Revisão estática manual: contratos entre UI/ViewModel/repositórios, consultas Room,
transações de inicialização, fechamento de DataStore nos testes, consentimento e
ciclo de vida da voz. Revisão não equivale a teste de execução.

## Bloqueio de compilação identificado

| Componente | Estado observado |
| --- | --- |
| Java | OpenJDK 21.0.12.1 presente; `java -m jdk.compiler/com.sun.tools.javac.Main -version` funciona |
| Executável javac | Não está no PATH nem no diretório bin; não confundir isso com ausência do módulo compilador |
| Gradle | Executável e distribuição ausentes |
| Kotlin/JUnit/AndroidX | Compilador e dependências de compilação/teste não disponíveis localmente |
| Android SDK | Sem `android.jar`, SDK Manager, Build Tools ou ADB instalados |
| Dispositivo/emulador | Nenhum disponível; `/dev/kvm` ausente |
| Wrapper | Apenas `.properties`; scripts e JAR oficiais ainda ausentes |
| Rede do comando | `curl` falha imediatamente ao conectar a `proxy:8080`, código 7 |

A política de rede do ambiente cloud aparece como `unrestricted/enforced`, mas
o executor sandboxed não consegue estabelecer a conexão ao proxy. As tentativas
anteriores com permissão adicional permaneceram aguardando autorização e foram
interrompidas. Não houve evidência de download ou de instalação concluída. Na última
retomada, uma verificação limitada a cinco segundos confirmou o erro imediato;
nenhuma nova solicitação de rede nem repetição de downloads foi feita depois disso.

Um timeout de `curl` não limita o tempo de uma solicitação de autorização que ocorre
antes de o comando começar. Essa foi a razão para abandonar novas tentativas nesta
sessão e preparar a compilação em outro executor. Não foi um erro conhecido do código
Kotlin: o compilador Android sequer foi iniciado.

## Testes escritos, não executados

| Conjunto | Quantidade | Estado |
| --- | ---: | --- |
| JVM: parser e provedor demonstrativo | 20 | Não executados |
| Android: Room e DataStore | 8 | Não executados |
| Android: navegação e fluxo de tarefas/comando noturno | 3 | Não executados |
| Voz, reinício real do processo e layout no tablet | Checklist manual | Não executados |

Os testes Room fecham e reabrem banco em arquivo. Os testes DataStore recriam o
store. Os testes UI recriam Activity, o que não prova sobrevivência à morte do
processo. Há roteiro separado em [ACCEPTANCE.md](ACCEPTANCE.md) e [VOICE.md](VOICE.md).

## O que falta para gerar e aceitar o APK

1. Em máquina/CI com rede funcional, instalar JDK 17, Gradle 8.10.2, SDK plataforma
   35 e Build Tools 35.0.0; aceitar licenças do SDK conforme o ambiente.
2. Baixar as dependências dos repositórios oficiais configurados.
3. Executar `gradle testDebugUnitTest lintDebug assembleDebug assembleDebugAndroidTest`;
   corrigir quaisquer erros reais encontrados. O esquema Room será gerado nessa etapa.
4. Executar os 11 testes instrumentados em emulador/tablet e guardar os relatórios.
5. Instalar `app/build/outputs/apk/debug/app-debug.apk` no tablet e executar o checklist
   manual de persistência, voz, teclado, rotação, exportação e acessibilidade.

O workflow incluído oferece essa rota pelo navegador do tablet. Ele não foi publicado
nem executado em uma conta externa. A geração opcional do wrapper genuíno está em
`scripts/create-wrapper.sh`; nenhum arquivo binário fictício foi criado.

## Limitações funcionais conhecidas

- IA real, notificações/lembretes, automações externas e módulos especializados
  permanecem planejados. Sarcasmo/formalidade/proatividade são preferências guardadas.
- Banco privado sem criptografia adicional, bloqueio biométrico ou importação de backup.
- Histórico de tarefas reflete conclusões atuais; não é auditoria de cada alteração.
- Históricos são carregados integralmente; paginação e retenção ainda não implementadas.
- Formulários fecham após solicitar gravação. Falhas de armazenamento são exibidas,
  mas recuperação automática do rascunho após erro de I/O ainda não existe.
- Limpar banco e redefinir preferências são operações sequenciais em stores diferentes.
- Voz depende dos mecanismos e modelos pt-BR do aparelho; Android 8–11 sem consentimento
  online exibe indisponibilidade de reconhecimento local e mantém entrada por texto.
- Previews Compose foram escritos, mas não renderizados. Não há captura de execução.
