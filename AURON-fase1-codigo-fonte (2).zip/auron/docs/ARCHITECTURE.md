# Arquitetura e decisões

## Escopo

Um módulo Gradle `app`, dividido por responsabilidade. Separar agora dezenas de
módulos aumentaria a manutenção sem benefício proporcional. Interfaces de domínio
permitem extrair módulos Gradle quando existir uma segunda implementação real.

```mermaid
flowchart TD
  UI[Compose: toque e texto] --> VM[ViewModel / estado]
  Voice[SpeechRecognizer pt-BR] --> VM
  VM --> Commands[Comandos locais explícitos]
  VM --> Provider[AiProvider]
  Provider --> Demo[DemoAiProvider: respostas fixas]
  Commands --> Repo[AuronRepository]
  VM --> Settings[SettingsRepository]
  Repo --> Room[Room: banco privado]
  Settings --> DS[DataStore]
  VM --> TTS[TextToSpeech offline]
  VM --> SAF[Exportação JSON solicitada pelo usuário]
```

## Escolhas

| Decisão | Motivo |
| --- | --- |
| Kotlin + Compose/Material 3 | Interface nativa adaptável, manutenção e acessibilidade Android |
| minSdk 26 | Suporte a tablets Android 8+, APIs java.time sem compatibilidade extra |
| target/compileSdk 35 | Base reproduzível da Fase 1; atualizar antes de publicar em loja |
| ViewModel + StateFlow | Sobrevive a recriação da Activity e observa dados persistidos |
| Room | SQL validado na compilação, transações e esquema exportado |
| DataStore | Preferências atômicas sem SharedPreferences síncrono |
| Injeção manual | Poucas dependências e fronteiras claras sem DI prematuro |
| Speech APIs / TTS | Serviços oficiais Android, sem API paga incorporada |
| Sem WorkManager ainda | Não há trabalho agendado real na Fase 1; adicionar com lembretes |

## Dados e tempo

Tarefas têm identificador UUID, título, observações, prioridade (0 baixa, 1 normal,
2 alta), prazo ISO opcional, criação e conclusão. Reabrir limpa a conclusão; o
histórico exibe o estado atual das tarefas concluídas, **não um log de auditoria de
todas as alterações**. Excluir uma tarefa também remove seu registro.

Itens da rotina são modelos editáveis. A conclusão tem chave `(itemId, day)` e
snapshot do título/período. Renomear ou excluir o modelo não apaga os snapshots
anteriores. Desmarcar remove a conclusão daquele dia. O dia usa o fuso configurado
no Android; mudar fuso/relógio altera a data operacional, sem reescrever o passado.

Seeds são inseridos uma única vez dentro de transação com metadado de inicialização.
Excluir a rotina ou limpar dados pelo app não restaura seeds automaticamente.
Desinstalar/limpar armazenamento pelo Android inicia uma nova instalação.

Chat e preferências persistem. Memória temporária limita-se a estado de interface
e operação em curso; não há memória semântica, inferência de preferências nem
recuperação contextual. Exportação captura coleções locais serializando ações
do ViewModel. Limpar tudo apaga Room e redefine DataStore em sequência: não há
transação distribuída entre ambos; falha de armazenamento é informada.

## IA e automações

`AiProvider` retorna `Success` ou `Unavailable`, declara identidade e se é demo.
Só `DemoAiProvider` está conectado. Antes de conectar um provedor real, adicionar
modelo de consentimento, estimativa/limite de custo, timeout/cancelamento, política
de retenção e tratamento de falhas. A interface atual não promete implementar
essas proteções de serviços externos.

Comandos são uma gramática limitada. Só submissões diretas do usuário chegam ao
parser. Texto de documentos, resposta de IA e conteúdo de APIs serão dados, nunca
instruções autorizadas. Comandos atuais apenas alteram tarefas/rotinas ou navegam.
Nenhum executor genérico de shell, intents externos ou acessibilidade está presente.

## Evolução do banco

Preservar `app/schemas`, incrementar versão e fornecer migrações explícitas.
Não usar `fallbackToDestructiveMigration`. Testar migrações e exportação antes de
entregar atualização para usuários com dados reais. Paginação de histórico e
retenção configurável são próximos trabalhos para volumes grandes.
