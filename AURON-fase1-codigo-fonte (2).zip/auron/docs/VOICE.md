# Voz na Fase 1

`VoiceController` adapta `SpeechRecognizer` e `TextToSpeech` do Android e expõe
`StateFlow<VoiceState>`. A Activity deve chamar `pause()` em `onStop()` e `close()`
em `onDestroy()`. Todas as operações de plataforma são encaminhadas à thread
principal. Os callbacks de sessões canceladas são descartados.

## Implementado

- Início de escuta por chamada explícita `start(allowOnline)`; a interface pede
  `RECORD_AUDIO` apenas após toque no microfone. A controladora também verifica a
  permissão antes de iniciar.
- Idioma `pt-BR`, transcrição final enviada ao callback, sem gravar arquivo de
  áudio. A aplicação decide o armazenamento da transcrição no histórico.
- Em Android 12/API 31 ou superior, preferência por
  `createOnDeviceSpeechRecognizer()`. Sem consentimento de voz online, só esse
  reconhecedor pode ser usado. A preferência `EXTRA_PREFER_OFFLINE` sozinha não
  garante processamento local e não é usada como substituto dessa restrição.
- Em Android 8–11 ou quando não há reconhecedor local, erro visível por padrão.
  Com consentimento explícito nas configurações, usa o serviço de reconhecimento
  selecionado no Android, que pode transmitir áudio ao provedor do serviço.
  Não há fallback automático para a nuvem quando a tentativa local falha.
- `stopListening()` encerra a captura e aguarda a transcrição; `pause()` cancela
  a sessão e descarta resultados pendentes. Limite de 45 segundos por captura
  e 12 segundos para resposta depois do encerramento, evitando sessão presa.
- Indicador de escuta, nível de áudio normalizado entre 0 e 1 e erros em pt-BR.
- Inicialização de TTS ao primeiro pedido de fala. Escolhe voz instalada `pt-BR`
  declarada offline pelo mecanismo Android. Não aceita voz com indicação
  `notInstalled` nem solicita downloads automaticamente. A garantia sobre o
  comportamento do mecanismo depende do serviço de TTS instalado no dispositivo.
- Velocidade limitada a 0,5–2,0; pedidos não finitos usam 1,0. Reprodução com
  `QUEUE_FLUSH`, interrupção explícita e eventos reais de início/fim/erro.
- A inicialização de TTS tem limite de 12 segundos. Enquanto inicializa, somente
  o último pedido de fala é mantido. Pausar o app remove esse pedido.
- Fechar o controlador libera reconhecedor, TTS e temporizadores; não existem
  serviços em segundo plano, escuta permanente ou palavra de ativação.

O manifesto precisa de `android.permission.RECORD_AUDIO` e de consultas de
visibilidade para `android.speech.RecognitionService` e
`android.intent.action.TTS_SERVICE`. O módulo não necessita de permissão própria
de internet; se autorizado, o serviço Android externo possui sua própria rede.

## Limitações conhecidas

- A disponibilidade de reconhecimento local em pt-BR varia por fabricante,
  versão Android, serviço e modelos instalados. A existência de um reconhecedor
  local não garante que seu modelo de pt-BR já esteja instalado.
- Um mecanismo de TTS sem voz offline pt-BR utilizável informa erro e mantém a
  resposta em texto. Não há escolha de mecanismo/voz dentro do AURON nesta fase;
  a instalação e a escolha do mecanismo são feitas nas configurações Android.
- Texto maior que `TextToSpeech.getMaxSpeechInputLength()` informa erro, sem
  truncamento silencioso. Segmentação de textos longos fica para próxima fase.
- O indicador `available` é o resultado da última tentativa de reconhecimento;
  a interface deve permitir nova tentativa após mudança de permissão ou serviço.
- Não há identificação de locutor, cancelamento acústico próprio, conversação
  contínua, palavra de ativação, seleção de voz ou reconhecimento de segundo plano.

## Roteiro de verificação em dispositivo

Este roteiro é executável no tablet. A presença do roteiro não significa que os
testes foram executados. Sem um Android conectado com serviços de fala instalados,
não é possível comprovar reconhecimento, áudio, permissão ou indicadores de
privacidade. O relatório geral do projeto registra as verificações executadas.

1. Em instalação limpa, tocar no microfone e negar a permissão: exibir orientação,
   sem iniciar captura. Conceder depois e tentar novamente: permitir retomada.
2. Android 12+ com modelo local pt-BR instalado e modo avião: dizer “mostre minha
   rotina”; conferir transcrição no chat e navegação pela aplicação. O indicador
   do microfone do Android deve aparecer apenas durante a captura.
3. Android 8–11 ou dispositivo sem reconhecedor local, consentimento desligado:
   conferir erro explícito e possibilidade de usar texto. Ligar consentimento
   após ler a explicação; repetir com serviço Android disponível e verificar a
   transcrição. Desligar consentimento e repetir: o modo externo deve ser bloqueado.
4. Iniciar escuta e ficar em silêncio; repetir com frase não reconhecível e
   serviço indisponível: conferir erro legível, indicador desligado e nova tentativa.
5. Dizer uma frase, tocar para parar e conferir entrega de no máximo uma
   transcrição. Repetir tocando rapidamente iniciar/parar/iniciar: resultados
   atrasados da sessão anterior não devem ser entregues.
6. Durante escuta, ir à tela inicial do Android, bloquear tela ou girar o tablet:
   o controlador antigo deve cancelar, liberar microfone e descartar transcrição
   atrasada. Voltar ao app e iniciar nova escuta explicitamente.
7. Instalar voz offline pt-BR no mecanismo TTS, habilitar respostas faladas,
   enviar “ajuda” com modo avião e conferir reprodução e indicador. Repetir com
   velocidades diferentes e interromper pelo botão de parar fala.
8. Sem voz offline pt-BR instalada, pedir fala: conferir instrução de instalação
   e ausência de download ou fallback de voz online dentro do AURON.
9. Durante inicialização/reprodução TTS, sair do app: nenhuma resposta pendente
   deve começar depois da saída. Voltar e pedir nova resposta; a fala deve poder
   funcionar normalmente. Iniciar escuta durante fala deve interromper TTS.
10. Repetir após revogar permissão do microfone nas configurações Android. Conferir
    recuperação sem fechar o app à força e sem registrar transcrição inexistente.

Para testes de interface automatizados, os serviços reais do fabricante precisam
ser tratados como dependências externas. Testes JVM não validam o comportamento
de `SpeechRecognizer` ou `TextToSpeech` em um tablet real.
