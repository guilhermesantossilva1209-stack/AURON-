# Privacidade da versão 0.1

- Nenhuma chave embutida, telemetria, analytics, anúncio ou SDK comercial de IA.
- O manifesto do app não solicita acesso à internet, arquivos gerais, contatos,
  localização, acessibilidade ou serviço de microfone em segundo plano.
- Room e DataStore ficam no sandbox privado do aplicativo. A proteção física em
  repouso depende do Android e do bloqueio do dispositivo; **não há criptografia
  adicional do banco nem proteção contra dispositivo desbloqueado/root**.
- Backups e transferência automática são excluídos no manifesto/regras Android.
  Implementações modificadas de fabricantes podem exigir validação adicional.
- Reconhecimento usa serviço local API31+ quando disponível. Em dispositivos sem
  esse serviço, o usuário pode consentir em usar o provedor do sistema, que pode
  transmitir áudio sob a própria política. A ausência de INTERNET no AURON não
  impede que outro serviço do Android use rede. O padrão é não autorizar.
- TTS seleciona uma voz pt-BR instalada e declarada offline pelo mecanismo. É uma
  dependência do sistema operacional e deve ser validada no tablet.
- Microfone é iniciado somente por toque; ao sair do app a captura e a fala são
  canceladas. Não há palavra de ativação, serviço em segundo plano ou escuta oculta.
- Exportação exige ação e escolha de destino no seletor Android. JSON contém todos
  os dados em texto legível; escolher um destino de nuvem pode enviar esse arquivo
  ao serviço escolhido pelo próprio usuário. Não há envio automático.
- Apagar conversas remove histórico do banco. Apagar todos os dados remove tarefas,
  rotinas, conclusões, conversa e redefine preferências. Isso não apaga arquivos
  anteriormente exportados, e não promete apagamento forense de armazenamento flash.

Antes dos módulos financeiro/emocional: implementar bloqueio local, gestão de
chaves Android Keystore, banco cifrado com dependência mantida, recuperação/backup
explicitamente consentido e testes do modelo de ameaças. Segredos de futuras APIs
nunca devem ficar no código ou em exportações; definir armazenamento protegido ou
um backend controlado antes de conectar qualquer provedor.
